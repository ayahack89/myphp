<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record page</title>
</head>
<style>
    body{
        font-family: Arial;
    }
    table,th,td{
        border: 2px solid black;
        border-collapse: collapse;
        padding: 5px;
        width: 800px;
        margin: 0 auto;
    }
    p{
        text-align: center;
    }

</style>
<body>

    <table>
       
        <th>STD ID</th>
        <th>STD NAME</th>
        <th>STD EMAIL</th>
        <th>STD PHONE</th>
        <?php 
            //Server details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "students";

//Connection
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Server not connected!".mysqli_error($conn));

//Sql fetch query
$sql = "SELECT * FROM `studentd`";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) > 0){
    while($row = mysqli_fetch_assoc($result)){

  ?>
        <tr>

            
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['stdname']; ?></td>
            <td><?php echo $row['stdemail']; ?></td>
            <td><?php echo $row['stdphonenum']; ?></td>
        </tr>
        <?php 
          }
        }

        ?>

    </table>
    <p>Click here to go the registration <a href="index.php"> form</a></p>
    
</body>
</html>